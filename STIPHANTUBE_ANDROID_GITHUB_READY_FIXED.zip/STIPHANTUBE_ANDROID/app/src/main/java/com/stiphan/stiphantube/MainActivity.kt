package com.stiphan.stiphantube

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView

    // Set this to your deployed STIPHANTUBE URL before building the APK.
    private val baseUrl = "https://YOUR-STIPHANTUBE-DOMAIN.example"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        setContentView(web)

        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent == null) return

        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent) {
        val sharedText = extractSharedText(intent)

        if (!sharedText.isNullOrBlank()) {
            // Keep the received text as a URL parameter so the web app can process it.
            // Uri.encode prevents malformed URLs from crashing WebView navigation.
            val target = "$baseUrl/dashboard?shared_url=${Uri.encode(sharedText)}"
            web.loadUrl(target)

            Toast.makeText(
                this,
                "URL received",
                Toast.LENGTH_SHORT
            ).show()
        } else {
            web.loadUrl("$baseUrl/dashboard")
        }
    }

    private fun extractSharedText(intent: Intent): String? {
        if (intent.action != Intent.ACTION_SEND || intent.type != "text/plain") {
            return null
        }

        return intent.getStringExtra(Intent.EXTRA_TEXT)
            ?.trim()
            ?.takeIf { it.isNotEmpty() }
    }
}
