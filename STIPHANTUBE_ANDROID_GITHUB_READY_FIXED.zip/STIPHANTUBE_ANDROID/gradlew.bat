@echo off
setlocal
set "APP_HOME=%~dp0"
java %JAVA_OPTS% %GRADLE_OPTS% -jar "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" %*
if errorlevel 1 exit /b %errorlevel%
endlocal
