# STIPHANTUBE Android Share App

This is the Android part that makes STIPHANTUBE appear in Android's Share sheet.

Before building the APK, edit `MainActivity.kt` and replace:
`https://YOUR-STIPHANTUBE-DOMAIN.example`
with the URL where the Next.js STIPHANTUBE server is deployed.

Then:
Instagram -> Share -> STIPHANTUBE -> shared URL opens automatically in STIPHANTUBE.
