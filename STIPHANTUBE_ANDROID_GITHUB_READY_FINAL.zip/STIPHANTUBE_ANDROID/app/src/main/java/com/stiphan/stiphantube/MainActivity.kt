package com.stiphan.stiphantube

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private val baseUrl = "https://YOUR-STIPHANTUBE-DOMAIN.example"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        setContentView(web)
        openShared(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) {
            setIntent(intent)
            openShared(intent)
        }
    }

    private fun openShared(intent: Intent?) {
        val sharedText = if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            intent.getStringExtra(Intent.EXTRA_TEXT)?.trim()
        } else {
            null
        }

        val target = if (!sharedText.isNullOrEmpty()) {
            "$baseUrl/dashboard?shared_url=${Uri.encode(sharedText)}"
        } else {
            "$baseUrl/dashboard"
        }
        web.loadUrl(target)
    }
}
