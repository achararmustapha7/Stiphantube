import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { getCurrentUser, toSafeUser } from "@/lib/auth";
import AppShell from "@/components/app-shell";

export const dynamic = "force-dynamic";

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  const user = await getCurrentUser();
  if (!user) {
    redirect("/login");
  }

  return <AppShell user={toSafeUser(user)}>{children}</AppShell>;
}
